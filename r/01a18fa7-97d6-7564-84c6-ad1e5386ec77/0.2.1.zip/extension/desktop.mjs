// ../../node_modules/.bun/@bridgething+extension@0.16.0+7524df1edfed9f02/node_modules/@bridgething/extension/dist/host.js
var ExtensionError = class extends Error {
  kind;
  constructor(message2, kind) {
    super(message2);
    this.kind = kind;
    this.name = "ExtensionError";
  }
};
async function* readLines(reader) {
  const decoder = new TextDecoder();
  let buffered = "";
  try {
    for (; ; ) {
      const { done, value } = await reader.read();
      if (done)
        break;
      buffered += decoder.decode(value, { stream: true });
      for (let cut = buffered.indexOf("\n"); cut >= 0; cut = buffered.indexOf("\n")) {
        const line = buffered.slice(0, cut);
        buffered = buffered.slice(cut + 1);
        if (line.trim().length > 0)
          yield line;
      }
    }
    buffered += decoder.decode();
    if (buffered.trim().length > 0)
      yield buffered;
  } finally {
    reader.releaseLock();
  }
}
var LineWriter = class {
  writer;
  encoder = new TextEncoder();
  tail = Promise.resolve();
  constructor(writable) {
    this.writer = writable.getWriter();
  }
  write(message2) {
    const chunk = this.encoder.encode(`${JSON.stringify(message2)}
`);
    const written = this.tail.then(() => this.writer.write(chunk));
    this.tail = written.catch(() => void 0);
    return written;
  }
  async close() {
    await this.tail;
    try {
      await this.writer.close();
    } catch {
      this.writer.releaseLock();
    }
  }
};

// ../../node_modules/.bun/@bridgething+extension@0.16.0+7524df1edfed9f02/node_modules/@bridgething/extension/dist/deno.js
function denoHost() {
  const runtime = globalThis.Deno;
  if (!runtime) {
    throw new ExtensionError("extensions run under deno; no Deno global in this process", "no-runtime");
  }
  return {
    readable: runtime.stdin.readable,
    writable: runtime.stdout.writable,
    exit: (code) => runtime.exit(code)
  };
}

// ../../node_modules/.bun/@bridgething+extension@0.16.0+7524df1edfed9f02/node_modules/@bridgething/extension/dist/message.js
function json(data) {
  return { encoding: "json", data };
}
function asJson(message2) {
  return message2.encoding === "json" ? message2.data : void 0;
}
var CHUNK = 32768;
function toBase64(bytes) {
  let latin1 = "";
  for (let i = 0; i < bytes.length; i += CHUNK) {
    latin1 += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
  }
  return btoa(latin1);
}
function fromBase64(data) {
  const latin1 = atob(data);
  const bytes = new Uint8Array(latin1.length);
  for (let i = 0; i < latin1.length; i++)
    bytes[i] = latin1.charCodeAt(i);
  return bytes;
}
function intoWire(message2) {
  if (typeof message2 === "string")
    return { encoding: "text", data: message2 };
  if (message2 instanceof Uint8Array)
    return { encoding: "binary", data: toBase64(message2) };
  if (message2.encoding === "binary")
    return { encoding: "binary", data: toBase64(message2.data) };
  return message2;
}
function fromWire(message2) {
  if (message2.encoding === "binary")
    return { encoding: "binary", data: fromBase64(message2.data) };
  return message2;
}

// ../../node_modules/.bun/@bridgething+extension@0.16.0+7524df1edfed9f02/node_modules/@bridgething/extension/dist/protocol.js
var EXTENSION_API_VERSION = 1;

// ../../node_modules/.bun/@bridgething+extension@0.16.0+7524df1edfed9f02/node_modules/@bridgething/extension/dist/runtime.js
function describe(value) {
  if (typeof value === "string")
    return value;
  if (value instanceof Error)
    return value.stack ?? `${value.name}: ${value.message}`;
  try {
    return JSON.stringify(value) ?? String(value);
  } catch {
    return String(value);
  }
}
var DeviceImpl = class {
  id;
  runtime;
  name = "";
  active = false;
  connected = false;
  config = {};
  constructor(id, runtime) {
    this.id = id;
    this.runtime = runtime;
  }
  send(message2) {
    this.runtime.forward(this.id, message2);
  }
};
var ExtensionRuntime = class {
  spec;
  host;
  writer;
  devices_ = /* @__PURE__ */ new Map();
  pending = /* @__PURE__ */ new Map();
  onDevice = /* @__PURE__ */ new Set();
  onMessage = /* @__PURE__ */ new Set();
  onConfig = /* @__PURE__ */ new Set();
  nextRequestId = 1;
  started = false;
  finishing;
  settled;
  helloApi = EXTENSION_API_VERSION;
  helloWebapp = { id: "", name: "", version: "" };
  helloDataDir = "";
  reader;
  constructor(spec, host) {
    this.spec = spec;
    this.host = host;
    this.writer = new LineWriter(host.writable);
  }
  get api() {
    return this.helloApi;
  }
  get webapp() {
    return this.helloWebapp;
  }
  get dataDir() {
    return this.helloDataDir;
  }
  get devices() {
    return [...this.devices_.values()].filter((device) => device.connected);
  }
  device(id) {
    return this.ensure(id);
  }
  broadcast(message2) {
    this.forward(void 0, message2);
  }
  config(device) {
    const id = typeof device === "string" ? device : device.id;
    return this.devices_.get(id)?.config ?? {};
  }
  on(event, listener) {
    if (event === "device") {
      const fn2 = listener;
      this.onDevice.add(fn2);
      return () => this.onDevice.delete(fn2);
    }
    if (event === "message") {
      const fn2 = listener;
      this.onMessage.add(fn2);
      return () => this.onMessage.delete(fn2);
    }
    const fn = listener;
    this.onConfig.add(fn);
    return () => this.onConfig.delete(fn);
  }
  kv = {
    get: (key) => this.request((id) => ({ t: "kv.get", id, key })).then((value) => value === null ? void 0 : value),
    set: (key, value) => this.request((id) => ({ t: "kv.set", id, key, value })).then(() => void 0),
    delete: (key) => this.request((id) => ({ t: "kv.delete", id, key })).then(() => void 0),
    list: () => this.request((id) => ({ t: "kv.list", id })).then((value) => value ?? [])
  };
  auth = {
    authorize: (url) => this.request((id) => ({ t: "auth.authorize", id, url })).then((value) => String(value))
  };
  log = {
    debug: (...args) => this.log.log("debug", ...args),
    info: (...args) => this.log.log("info", ...args),
    warn: (...args) => this.log.log("warn", ...args),
    error: (...args) => this.log.log("error", ...args),
    log: (level, ...args) => {
      this.emit({ t: "log", level, message: args.map(describe).join(" ") });
    }
  };
  forward(device, message2) {
    const wire = intoWire(message2);
    this.emit(device === void 0 ? { t: "device.send", message: wire } : { t: "device.send", device, message: wire });
  }
  async run() {
    this.reader = this.host.readable.getReader();
    try {
      for await (const line of readLines(this.reader)) {
        const message2 = this.parse(line);
        if (!message2)
          continue;
        if (message2.t === "stop") {
          await this.finish(0);
          return;
        }
        this.dispatch(message2);
      }
    } catch (err) {
      await this.finish(1, new ExtensionError(`stdin read failed: ${describe(err)}`, "disconnected"));
      return;
    }
    await this.finish(0);
  }
  ensure(id) {
    const existing = this.devices_.get(id);
    if (existing)
      return existing;
    const fresh = new DeviceImpl(id, this);
    this.devices_.set(id, fresh);
    return fresh;
  }
  parse(line) {
    try {
      return JSON.parse(line);
    } catch (err) {
      this.log.error(`unparseable line from host: ${describe(err)}`);
      return void 0;
    }
  }
  dispatch(message2) {
    switch (message2.t) {
      case "hello": {
        this.helloApi = message2.api;
        this.helloWebapp = message2.webapp;
        this.helloDataDir = message2.dataDir;
        this.begin();
        return;
      }
      case "device.connected": {
        const device = this.ensure(message2.device);
        device.name = message2.name;
        device.config = { ...message2.config };
        device.active = message2.active;
        device.connected = true;
        this.announce({ type: "connected", device });
        return;
      }
      case "device.disconnected": {
        const device = this.devices_.get(message2.device);
        if (!device)
          return;
        device.connected = false;
        device.active = false;
        this.announce({ type: "disconnected", device });
        return;
      }
      case "device.active": {
        const device = this.ensure(message2.device);
        device.active = message2.active;
        this.announce({ type: "active", device });
        return;
      }
      case "device.message": {
        const device = this.ensure(message2.device);
        const forwarded = this.guard(() => fromWire(message2.message));
        if (!forwarded)
          return;
        for (const listener of [...this.onMessage])
          this.guard(() => listener(device, forwarded));
        return;
      }
      case "config.changed": {
        const device = this.ensure(message2.device);
        const next = { ...device.config };
        if (message2.value === null)
          delete next[message2.key];
        else
          next[message2.key] = message2.value;
        device.config = next;
        for (const listener of [...this.onConfig]) {
          this.guard(() => listener(device, message2.key, message2.value));
        }
        return;
      }
      case "reply": {
        const waiting = this.pending.get(message2.id);
        if (!waiting)
          return;
        this.pending.delete(message2.id);
        if (message2.ok)
          waiting.resolve(message2.value);
        else
          waiting.reject(new ExtensionError(message2.error, "host-error"));
        return;
      }
    }
  }
  begin() {
    if (this.started)
      return;
    this.started = true;
    let starting;
    try {
      starting = this.spec.start(this);
    } catch (err) {
      this.abortStart(err);
      return;
    }
    void Promise.resolve(starting).then(() => this.emit({ t: "ready" }), (err) => this.abortStart(err));
  }
  abortStart(err) {
    this.log.error(`start failed: ${describe(err)}`);
    void this.finish(1, new ExtensionError(describe(err), "host-error"));
  }
  announce(event) {
    for (const listener of [...this.onDevice])
      this.guard(() => listener(event));
  }
  guard(run) {
    try {
      return run();
    } catch (err) {
      this.log.error(describe(err));
      return void 0;
    }
  }
  emit(message2) {
    this.writer.write(message2).catch((err) => {
      void this.finish(1, new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
    });
  }
  request(build) {
    if (this.settled) {
      const advice = "kv and auth cannot be reached once shutdown has begun, so persist eagerly rather than from stop";
      return Promise.reject(new ExtensionError(`${this.settled.message}; ${advice}`, this.settled.kind));
    }
    const id = String(this.nextRequestId++);
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.writer.write(build(id)).catch((err) => {
        if (!this.pending.delete(id))
          return;
        reject(new ExtensionError(`stdout write failed: ${describe(err)}`, "write-failed"));
      });
    });
  }
  finish(code, reason) {
    this.finishing ??= this.shutdown(code, reason);
    return this.finishing;
  }
  async shutdown(code, reason) {
    const failure = reason ?? new ExtensionError("the host closed the connection", "disconnected");
    this.settled = failure;
    await this.reader?.cancel().catch(() => void 0);
    for (const waiting of [...this.pending.values()])
      waiting.reject(failure);
    this.pending.clear();
    try {
      await this.spec.stop?.();
    } catch (err) {
      await this.writer.write({ t: "log", level: "error", message: `stop failed: ${describe(err)}` }).catch(() => void 0);
    }
    await this.writer.close();
    this.host.exit(code);
  }
};

// ../../node_modules/.bun/@bridgething+extension@0.16.0+7524df1edfed9f02/node_modules/@bridgething/extension/dist/index.js
function defineExtension(spec, host = denoHost()) {
  return new ExtensionRuntime(spec, host).run();
}

// extension/main.ts
var OSASCRIPT = "/usr/bin/osascript";
var BEAT_MS = 5e3;
var WATCH = `
ObjC.import('CoreGraphics');
var last = '';
while (true) {
  var now = $.CGDisplayIsAsleep($.CGMainDisplayID()) ? 'asleep' : 'awake';
  if (now !== last) { console.log(now); last = now; }
  delay(2);
}`;
var child = null;
var stopped = false;
var asleep = null;
var beat;
function message() {
  return { type: "display", asleep, supported: Deno.build.os === "darwin" };
}
async function watch(ctx, onChange) {
  let backoff = 2e3;
  while (!stopped) {
    const started = Date.now();
    try {
      child = new Deno.Command(OSASCRIPT, {
        args: ["-l", "JavaScript", "-e", WATCH],
        stdin: "null",
        stdout: "null",
        stderr: "piped"
      }).spawn();
      const reader = child.stderr.getReader();
      const decoder = new TextDecoder();
      let buf = "";
      for (; ; ) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        let nl;
        while ((nl = buf.indexOf("\n")) >= 0) {
          const line = buf.slice(0, nl).trim();
          buf = buf.slice(nl + 1);
          if (line === "asleep" || line === "awake") onChange(line === "asleep");
          else if (line) ctx.log.warn(`display watcher: ${line}`);
        }
      }
      await child.status;
    } catch (err) {
      ctx.log.warn(`display watcher failed to start: ${String(err)}`);
    }
    child = null;
    if (stopped) return;
    backoff = Date.now() - started > 6e4 ? 2e3 : Math.min(backoff * 2, 5 * 6e4);
    await new Promise((r) => setTimeout(r, backoff));
  }
}
defineExtension({
  start(ctx) {
    ctx.on("device", (event) => {
      if (event.type === "active" || event.type === "connected") event.device.send(json(message()));
    });
    ctx.on("message", (device, msg) => {
      if (asJson(msg)?.type === "hello") device.send(json(message()));
    });
    beat = setInterval(() => ctx.broadcast(json(message())), BEAT_MS);
    if (Deno.build.os !== "darwin") {
      ctx.log.info(`display following is mac only; ${Deno.build.os} reports unsupported`);
      return;
    }
    void watch(ctx, (next) => {
      if (next === asleep) return;
      asleep = next;
      ctx.log.info(`display ${next ? "asleep" : "awake"}`);
      ctx.broadcast(json(message()));
    });
  },
  stop() {
    stopped = true;
    clearInterval(beat);
    try {
      child?.kill("SIGTERM");
    } catch {
    }
  }
});
